function edit(){
    var a=document.querySelector("p");
    console.log(a);
    var b=document.querySelector("#b");
    console.log(b);
    var c=document.querySelectorAll("p");
    // c.forEach(function(a)
    // {
    //     console.log(a.textContent);
    // })
    for(var i=0;i<c.length;i++){
        console.log(c[i].textContent);
    }
    // var d=document.querySelectorAll("p");
    // for(var i=0;i<d.length;i++)
    // {
    //     d[i].style.color="blue";
    //     d[i].style.background="white";
    //     d[i].style.border="1px solid black";
    //     d[i].style.fontSize="20px";
    //     d[i].style.fontFamily="Arial,sans-serif";
    // }
    var e=document.querySelectorAll("p");
    for(var i=0;i<e.length;i++)
    {
        if(i%2===0)
        {
            e[i].style.color="blue";
        }
        else{
            e[i].style.color="red";
        }
    }
}
edit()