const addProductBtn = document.getElementById("addProductBtn");
        const productDetailsDiv = document.getElementById("productDetails");

        addProductBtn.addEventListener("click", function() {
            const form = document.createElement("form");

            const productNameLabel = document.createElement("label");
            productNameLabel.textContent = "Product Name: ";
            const productNameInput = document.createElement("input");
            productNameInput.type = "text";
            form.appendChild(productNameLabel);
            form.appendChild(productNameInput);
            form.appendChild(document.createElement("br"));

            const productDescLabel = document.createElement("label");
            productDescLabel.textContent = "Product Description: ";
            const productDescInput = document.createElement("input");
            productDescInput.type = "text";
            form.appendChild(productDescLabel);
            form.appendChild(productDescInput);
            form.appendChild(document.createElement("br"));

            const productImageLabel = document.createElement("label");
            productImageLabel.textContent = "Product Image: ";
            const productImageInput = document.createElement("input");
            productImageInput.type = "file";
            form.appendChild(productImageLabel);
            form.appendChild(productImageInput);
            form.appendChild(document.createElement("br"));

            const productPriceLabel = document.createElement("label");
            productPriceLabel.textContent = "Product Price: ";
            const productPriceInput = document.createElement("input");
            productPriceInput.type = "text";
            form.appendChild(productPriceLabel);
            form.appendChild(productPriceInput);
            form.appendChild(document.createElement("br"));

            const submitBtn = document.createElement("input");
            submitBtn.type = "submit";
            submitBtn.value = "Submit";
            form.appendChild(submitBtn);

            form.addEventListener("submit", function(event) {
                event.preventDefault();

                const newProduct = document.createElement("div");

                const productName = document.createElement("p");
                productName.textContent = "Product Name: " + productNameInput.value;
                newProduct.appendChild(productName);

                const productDesc = document.createElement("p");
                productDesc.textContent = "Product Description: " + productDescInput.value;
                newProduct.appendChild(productDesc);

                const productImage = document.createElement("img");
                productImage.src = productImageInput.value; // Assuming the input contains the image URL
                newProduct.appendChild(productImage);

                const productPrice = document.createElement("p");
                productPrice.textContent = "Product Price: $" + productPriceInput.value;
                newProduct.appendChild(productPrice);

                productDetailsDiv.appendChild(newProduct);
                form.reset();
            });

            productDetailsDiv.appendChild(form);
        });
