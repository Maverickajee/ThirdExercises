var colors = ["indigo", "seagreen", "peru", "navy"]; // Array of colors
    var currentIndex = 0; // Current color index

    function updateTime() {
      var currentTime = new Date();
      var hours = currentTime.getHours();
      var minutes = currentTime.getMinutes();
      var seconds = currentTime.getSeconds();

      var formattedTime ="Current Time: "+ hours + ":" + minutes + ":" + seconds;
      var timeElement = document.getElementById("time");

      // Change color every three seconds
      if (currentIndex >= colors.length) {
        currentIndex = 0;
      }
      timeElement.style.color = colors[currentIndex];
      currentIndex++;

      timeElement.textContent = formattedTime;
    }

    setInterval(updateTime, 3000); // Call updateTime every three seconds (3000 milliseconds)
    

    const yearElement = document.getElementById('year');

function changeYearColor() {
  const year = new Date().getFullYear();
  const colors = ['red', 'blue', 'green', 'yellow']; // List of colors

  const randomColor = colors[Math.floor(Math.random() * colors.length)];
  yearElement.style.color = randomColor;
  yearElement.textContent = year;
}

// Call the function initially
changeYearColor();

// Call the function every 3 seconds
setInterval(changeYearColor, 3000);


const first = document.getElementsByClassName('one');

for (let i = 0; i < first.length; i++) {
  first[i].style.backgroundColor = 'cyan';
}
 
const second=document.getElementsByClassName("two");

 for(let i=0;i<second.length;i++)
 {
  second[i].style.backgroundColor='hotpink';
 }

 const third=document.getElementsByClassName("three");

 for(let i=0;i<third.length;i++)
 {
  third[i].style.backgroundColor='plum';
 }

  